#include<iostream>
#include<string>
int main()
{
    std::string s;
    std::cout<<s[0]<<std::endl;


    return 0;
}
