#include "head"
int fun1()
{
    std::cout<<"i am  fun1"<<std::endl;
        return 0;
}
