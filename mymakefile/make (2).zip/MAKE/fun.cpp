#include "head"
int fun()
{
    std::cout<<"i am fun"<<std::endl;
    return 0;
}
