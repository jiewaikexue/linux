#include "head"

int main()
{
    fun();
    fun1();
    std::cout<<"helloworld"<<std::endl;
    return 0;
}
