#include<iostream>
using namespace std;
int main()
{
    char q='q';
    cout<<(~q<<6)<<endl;
    return 0;
}
